package com.pmba.publicacoes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PublicacoesApplication {

	public static void main(String[] args) {
		SpringApplication.run(PublicacoesApplication.class, args);
	}

}
