package com.pmba.publicacoes.model;

public enum StatusPublicacao {
    ATIVA,
    REVOGADA
}