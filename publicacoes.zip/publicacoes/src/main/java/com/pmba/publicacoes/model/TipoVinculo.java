package com.pmba.publicacoes.model;

public enum TipoVinculo {
    REVOGA,
    ALTERA,
    REVOGA_PARCIALMENTE,
    CORRELACIONA
}