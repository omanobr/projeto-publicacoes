package com.pmba.publicacoes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PublicacoesApplicationTests {

	@Test
	void contextLoads() {
	}

}
